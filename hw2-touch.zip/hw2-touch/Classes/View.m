//
//  View.m
//  Touch
//
//  Created by NYU User on 10/28/10.
//  Edited by sha sha feng july 2011 for HW2
//  The square loads in a random position and will move away 
//  from the user when the user touches it.

#import "View.h"



@implementation View


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor blackColor];
		
		// Get random value between 0 and 319
		int x = arc4random() % 320;
		
		// Get random number between 0 and 459
		int y =  arc4random() % 460;
		
		//set random coordinates for rectangle to appear
		CGRect f = CGRectMake(x, y, 50, 50);
		view = [[UIView alloc] initWithFrame: f];
		view.backgroundColor = [UIColor whiteColor];
		[self addSubview: view];
	}
	return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count > 0) {
		
//modified, shape will avoid touched spot
		
		//UITouch *t = [touches anyObject];
		//CGPoint p = [t locationInView: self];
		CGFloat x= arc4random() % 320;
		CGFloat y= arc4random() % 460;;
		CGPoint p = CGPointMake(x, y);
		view.center = p;	//Move the view to a new location.
		
		//Can combine the above three statements to
		//view.center = [[touches anyObject] locationInView: self];
	}
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
    // Drawing code
}
*/

- (void) dealloc {
	[view release];
	[super dealloc];
}


@end
