//
//  main.m
//  Touch
//
//  Created by NYU User on 10/28/10.
//  Edited by sha sha feng july 2011 for HW2
//  The square loads in a random position and will move to random position 
//  when the user touches the screen.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"TouchAppDelegate");
	[pool release];
	return retVal;
}
