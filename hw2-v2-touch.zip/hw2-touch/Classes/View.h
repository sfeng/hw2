//
//  View.h
//  Touch
//
//  Created by NYU User on 10/28/10.
//  Edited by sha sha feng july 2011 for HW2
//  The square loads in a random position and will move away 
//  from the user when the user touches it.

#import <UIKit/UIKit.h>


@interface View: UIView {
	UIView *view;
}

@end
